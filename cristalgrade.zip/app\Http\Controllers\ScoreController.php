<?php

namespace App\Http\Controllers;

use App\Models\Score;
use App\Models\User;
use App\Models\Activity;
use Illuminate\Http\Request;

class ScoreController extends Controller
{
    // Show all scores for a given activity
    public function index(Activity $activity)
    {
        $scores = Score::where('activity_id', $activity->id)
                        ->with('student') // changed from student → user
                        ->get();

        return view('scores.index', compact('activity', 'scores'));
    }

    // Show form to add/edit scores for all students in a class
    public function edit(Activity $activity)
    {
        $students = $activity->class->students; // still fine if your Class model relation is ->students()
        $scores = $activity->scores->keyBy('student_id'); // changed from student_id → user_id

        return view('scores.edit', compact('activity', 'students', 'scores'));
    }

    // Save/update scores for single activity
    public function update(Request $request, Activity $activity)
    {
        foreach ($request->scores as $userId => $scoreValue) {
            Score::updateOrCreate(
                [
                    'user_id' => $userId,        // changed
                    'activity_id' => $activity->id,
                ],
                [
                    'score' => $scoreValue,
                ]
            );
        }

        return redirect()->route('scores.index', $activity)->with('success', 'Scores updated successfully.');
    }

    // Save/update scores for entire class (students x activities)
   public function saveScores(Request $request, $classId)
{
    $scoresData = $request->input('scores', []);

    // basic validation (optional)
    // $request->validate(['scores' => 'array']);
    
    foreach ($scoresData as $studentKey => $activities) {
        foreach ($activities as $activityId => $scoreValue) {
            // normalize empty to null
            if ($scoreValue === '' || $scoreValue === null) {
                // if you want to delete blank entries: Score::where(...)->delete();
                continue;
            }

            // If your DB column is user_id:
            Score::updateOrCreate(
                [
                    'student_id'     => (int) $studentKey,
                    'activity_id' => (int) $activityId,
                ],
                [
                    'score' => $scoreValue,
                ]
            );

            // If your DB column is student_id (instead), use:
            // Score::updateOrCreate(['student_id'=> (int)$studentKey, 'activity_id'=>...], ['score'=>$scoreValue]);
        }
    }

    return back()->with('success', 'Scores updated successfully!');
}
    public function showScores($activity_id)
    {
        $activity = Activity::with('scores.student')->find($activity_id);
        return view('activities.scores', compact('activity'));
    }
}
