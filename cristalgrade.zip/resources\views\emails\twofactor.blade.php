<h2>Hello {{ $user->name }},</h2>
<p>Your CristalGrade verification code is:</p>
<h1 style="color:#2c3e50;">{{ $user->two_factor_code }}</h1>
<p>This code will expire in 10 minutes. If you didn’t request it, please ignore this email.</p>
